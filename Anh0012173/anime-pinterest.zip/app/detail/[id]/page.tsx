import Image from "next/image"
import Link from "next/link"
import { Heart, Share2, Download, ArrowLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"

const imageDetails = {
  id: 1,
  src: "/placeholder.svg?height=600&width=800",
  title: "Beautiful Anime Character",
  owner: "danbooru",
  change: "1751871633",
  imageId: "5909168",
  size: "2048 x 1152",
  status: "active",
  rating: "general",
  commentCount: 0,
  tags: [
    { name: "commentary_request", color: "bg-blue-100 text-blue-800" },
    { name: "hat", color: "bg-yellow-100 text-yellow-800" },
    { name: "hair_between_eyes", color: "bg-green-100 text-green-800" },
    { name: "red_eyes", color: "bg-pink-100 text-pink-800" },
    { name: "thighhighs", color: "bg-purple-100 text-purple-800" },
    { name: "dress", color: "bg-orange-100 text-orange-800" },
    { name: "persona_4", color: "bg-indigo-100 text-indigo-800" },
    { name: "jewelry", color: "bg-teal-100 text-teal-800" },
    { name: "standing", color: "bg-violet-100 text-violet-800" },
    { name: "hair_ornament", color: "bg-gray-100 text-gray-800" },
    { name: "closed_mouth", color: "bg-rose-100 text-rose-800" },
    { name: "jack_o_gloves", color: "bg-cyan-100 text-cyan-800" },
    { name: "blue_cape", color: "bg-sky-100 text-sky-800" },
    { name: "cape", color: "bg-emerald-100 text-emerald-800" },
    { name: "cleo_(dragalia_lost)", color: "bg-amber-100 text-amber-800" },
    { name: "cleo_(gala)_(dragalia_lost)", color: "bg-lime-100 text-lime-800" },
    { name: "commission", color: "bg-fuchsia-100 text-fuchsia-800" },
    { name: "dragalia_lost", color: "bg-red-100 text-red-800" },
    { name: "drill_hair", color: "bg-green-200 text-green-900" },
    { name: "fingerless_gloves", color: "bg-blue-200 text-blue-900" },
    { name: "gloves", color: "bg-purple-200 text-purple-900" },
    { name: "hair_bell", color: "bg-pink-200 text-pink-900" },
    { name: "hair_ornament", color: "bg-yellow-200 text-yellow-900" },
    { name: "highres", color: "bg-indigo-200 text-indigo-900" },
    { name: "holding", color: "bg-teal-200 text-teal-900" },
    { name: "holding_staff", color: "bg-orange-200 text-orange-900" },
    { name: "long_hair", color: "bg-violet-200 text-violet-900" },
    { name: "long_sleeves", color: "bg-green-300 text-green-900" },
    { name: "open_mouth", color: "bg-blue-300 text-blue-900" },
    { name: "pink_eyes", color: "bg-pink-300 text-pink-900" },
    { name: "pink_hair", color: "bg-purple-300 text-purple-900" },
    { name: "rabbit_ears", color: "bg-yellow-300 text-yellow-900" },
    { name: "re_(pixiv_89203939)", color: "bg-indigo-300 text-indigo-900" },
    { name: "solo", color: "bg-teal-300 text-teal-900" },
    { name: "staff", color: "bg-orange-300 text-orange-900" },
    { name: "twin_drills", color: "bg-violet-300 text-violet-900" },
    { name: "two-tone_cape", color: "bg-green-400 text-green-900" },
    { name: "very_long_hair", color: "bg-blue-400 text-blue-900" },
    { name: "vgen_commission", color: "bg-pink-400 text-pink-900" },
  ],
}

const relatedImages = [
  { id: 2, src: "/placeholder.svg?height=200&width=200", title: "Related Image 1" },
  { id: 3, src: "/placeholder.svg?height=200&width=200", title: "Related Image 2" },
  { id: 4, src: "/placeholder.svg?height=200&width=200", title: "Related Image 3" },
  { id: 5, src: "/placeholder.svg?height=200&width=200", title: "Related Image 4" },
  { id: 6, src: "/placeholder.svg?height=200&width=200", title: "Related Image 5" },
  { id: 7, src: "/placeholder.svg?height=200&width=200", title: "Related Image 6" },
  { id: 8, src: "/placeholder.svg?height=200&width=200", title: "Related Image 7" },
  { id: 9, src: "/placeholder.svg?height=200&width=200", title: "Related Image 8" },
]

export default function DetailPage({ params }: { params: { id: string } }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-purple-100 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/" className="flex items-center space-x-2">
                <div className="w-10 h-10 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-lg">P</span>
                </div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
                  Pinterest Anime
                </h1>
              </Link>
              <Button variant="outline" className="bg-blue-500 text-white border-blue-500 hover:bg-blue-600">
                Back out
              </Button>
            </div>

            <Link href="/">
              <Button variant="outline">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Quay lại
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Image */}
          <div className="lg:col-span-2">
            <Card className="overflow-hidden shadow-2xl">
              <div className="relative">
                <Image
                  src={imageDetails.src || "/placeholder.svg"}
                  alt={imageDetails.title}
                  width={800}
                  height={600}
                  className="w-full h-auto object-cover"
                />
                <div className="absolute top-4 right-4 flex space-x-2">
                  <Button size="sm" className="bg-white/80 text-gray-800 hover:bg-white">
                    <Heart className="w-4 h-4 mr-1" />
                    Thích
                  </Button>
                  <Button size="sm" className="bg-white/80 text-gray-800 hover:bg-white">
                    <Share2 className="w-4 h-4 mr-1" />
                    Chia sẻ
                  </Button>
                  <Button size="sm" className="bg-white/80 text-gray-800 hover:bg-white">
                    <Download className="w-4 h-4 mr-1" />
                    Tải về
                  </Button>
                </div>
              </div>
            </Card>
          </div>

          {/* Image Details */}
          <div className="space-y-6">
            <Card>
              <CardContent className="p-6">
                <h2 className="text-2xl font-bold mb-4 text-gray-800">Thông tin chi tiết</h2>

                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="font-medium text-gray-600">Owner:</span>
                    <span className="text-gray-800">{imageDetails.owner}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium text-gray-600">Change:</span>
                    <span className="text-gray-800">{imageDetails.change}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium text-gray-600">ID:</span>
                    <span className="text-gray-800">{imageDetails.imageId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium text-gray-600">Size:</span>
                    <span className="text-gray-800">{imageDetails.size}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium text-gray-600">Status:</span>
                    <span className="text-green-600 font-medium">{imageDetails.status}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium text-gray-600">Rating:</span>
                    <span className="text-gray-800">{imageDetails.rating}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium text-gray-600">Comments:</span>
                    <span className="text-gray-800">{imageDetails.commentCount}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <h3 className="text-lg font-bold mb-4 text-gray-800">Tags</h3>
                <div className="flex flex-wrap gap-2 max-h-64 overflow-y-auto">
                  {imageDetails.tags.map((tag, index) => (
                    <Badge key={index} variant="secondary" className={`${tag.color} text-xs`}>
                      {tag.name}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Related Images */}
        <div className="mt-12">
          <h3 className="text-2xl font-bold mb-6 text-gray-800">Hình ảnh liên quan</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-4">
            {relatedImages.map((image) => (
              <Link key={image.id} href={`/detail/${image.id}`}>
                <div className="group relative aspect-square overflow-hidden rounded-lg bg-white shadow-md hover:shadow-xl transition-all duration-300">
                  <Image
                    src={image.src || "/placeholder.svg"}
                    alt={image.title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
                  <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <p className="text-white text-xs font-medium truncate">{image.title}</p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
