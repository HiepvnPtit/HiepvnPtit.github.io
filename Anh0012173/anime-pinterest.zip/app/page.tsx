import Image from "next/image"
import Link from "next/link"
import { Search, Heart, Share2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

const featuredImages = [
  {
    id: 1,
    src: "/placeholder.svg?height=300&width=250",
    title: "1girl artist_name be...",
    owner: "danbooru",
    tags: ["red_eyes", "thighhighs", "dress", "persona_4", "jewelry"],
  },
  {
    id: 2,
    src: "/placeholder.svg?height=300&width=250",
    title: "2girls a_fragment_of...",
    owner: "danbooru",
    tags: ["standing", "hair_ornament", "closed_mouth"],
  },
  {
    id: 3,
    src: "/placeholder.svg?height=300&width=250",
    title: "1girl ascot blonde_h...",
    owner: "danbooru",
    tags: ["commentary_request", "hat", "hair_between_eyes"],
  },
  {
    id: 4,
    src: "/placeholder.svg?height=300&width=250",
    title: "2girls arms_behind_b...",
    owner: "danbooru",
    tags: ["blue_cape", "cape", "fingerless_gloves"],
  },
  {
    id: 5,
    src: "/placeholder.svg?height=300&width=250",
    title: "1girl ascot blonde_h...",
    owner: "danbooru",
    tags: ["gloves", "hair_bell", "hair_ornament"],
  },
  {
    id: 6,
    src: "/placeholder.svg?height=300&width=250",
    title: "1boy arms_up black_b...",
    owner: "danbooru",
    tags: ["highres", "holding", "holding_staff"],
  },
]

const sidebarImages = [
  { id: 7, src: "/placeholder.svg?height=150&width=200", title: "Anime Art 1" },
  { id: 8, src: "/placeholder.svg?height=150&width=200", title: "Anime Art 2" },
  { id: 9, src: "/placeholder.svg?height=150&width=200", title: "Anime Art 3" },
  { id: 10, src: "/placeholder.svg?height=150&width=200", title: "Anime Art 4" },
]

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-purple-100 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-lg">P</span>
                </div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
                  Pinterest Anime
                </h1>
              </div>
              <Button variant="outline" className="bg-blue-500 text-white border-blue-500 hover:bg-blue-600">
                Back out
              </Button>
            </div>

            <div className="flex items-center space-x-4">
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                  commentary_request
                </Badge>
                <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                  hat
                </Badge>
                <Badge variant="secondary" className="bg-green-100 text-green-800">
                  hair_between_eyes
                </Badge>
                <Badge variant="secondary" className="bg-pink-100 text-pink-800">
                  red_eyes
                </Badge>
                <Badge variant="secondary" className="bg-purple-100 text-purple-800">
                  thighhighs
                </Badge>
              </div>

              <div className="flex items-center space-x-2">
                <Input placeholder="Nhập tags (vd: hatsune_miku long_hair)" className="w-64" />
                <Button className="bg-blue-500 hover:bg-blue-600">Tìm kiếm</Button>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-96 overflow-hidden">
        <Image src="/images/hero-bg.png" alt="Hero Background" fill className="object-cover opacity-60" />
        <div className="absolute inset-0 bg-gradient-to-r from-purple-900/50 to-pink-900/50" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white">
            <h2 className="text-6xl font-bold mb-4 opacity-80">Distorted Fate</h2>
            <p className="text-xl opacity-70">Khám phá thế giới anime tuyệt đẹp</p>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 py-8">
        <div className="flex gap-8">
          {/* Main Content */}
          <div className="flex-1">
            <h3 className="text-2xl font-bold mb-6 text-gray-800">Hình ảnh nổi bật</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredImages.map((image) => (
                <Link key={image.id} href={`/detail/${image.id}`}>
                  <div className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden group">
                    <div className="relative">
                      <Image
                        src={image.src || "/placeholder.svg"}
                        alt={image.title}
                        width={250}
                        height={300}
                        className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <div className="flex space-x-1">
                          <Button size="sm" variant="secondary" className="w-8 h-8 p-0">
                            <Heart className="w-4 h-4" />
                          </Button>
                          <Button size="sm" variant="secondary" className="w-8 h-8 p-0">
                            <Share2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                    <div className="p-4">
                      <h4 className="font-semibold text-gray-800 mb-2 truncate">{image.title}</h4>
                      <p className="text-sm text-gray-600 mb-3">owner: {image.owner}</p>
                      <div className="flex flex-wrap gap-1">
                        {image.tags.slice(0, 3).map((tag, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                        {image.tags.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{image.tags.length - 3}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>

          {/* Sidebar */}
          <div className="w-80">
            <h3 className="text-xl font-bold mb-4 text-gray-800">Gợi ý cho bạn</h3>
            <div className="space-y-4">
              {sidebarImages.map((image) => (
                <Link key={image.id} href={`/detail/${image.id}`}>
                  <div className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow overflow-hidden">
                    <Image
                      src={image.src || "/placeholder.svg"}
                      alt={image.title}
                      width={200}
                      height={150}
                      className="w-full h-32 object-cover"
                    />
                    <div className="p-3">
                      <p className="text-sm font-medium text-gray-800">{image.title}</p>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <div className="fixed bottom-6 right-6 flex space-x-2">
        <Link href="/search">
          <Button className="bg-purple-500 hover:bg-purple-600 text-white rounded-full w-12 h-12 p-0">
            <Search className="w-5 h-5" />
          </Button>
        </Link>
      </div>
    </div>
  )
}
