import Image from "next/image"
import Link from "next/link"
import { Grid, List, Filter } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

const searchResults = [
  { id: 1, src: "/placeholder.svg?height=200&width=200", title: "1boy cup drinking_gl..." },
  { id: 2, src: "/placeholder.svg?height=200&width=200", title: "1boy 1girl ahoge all..." },
  { id: 3, src: "/placeholder.svg?height=200&width=200", title: "3girls absurdres ano..." },
  { id: 4, src: "/placeholder.svg?height=200&width=200", title: "1girl absurdres ahog..." },
  { id: 5, src: "/placeholder.svg?height=200&width=200", title: "1girl d absurdres a..." },
  { id: 6, src: "/placeholder.svg?height=200&width=200", title: "1girl absurdres ahog..." },
  { id: 7, src: "/placeholder.svg?height=200&width=200", title: "1boy 1other alternat..." },
  { id: 8, src: "/placeholder.svg?height=200&width=200", title: "1girl absurdres barb..." },
  { id: 9, src: "/placeholder.svg?height=200&width=200", title: "1boy 1girl adher_(g..." },
  { id: 10, src: "/placeholder.svg?height=200&width=200", title: "1boy 1girl absurdres..." },
  { id: 11, src: "/placeholder.svg?height=200&width=200", title: "1girl armor black_ar..." },
  { id: 12, src: "/placeholder.svg?height=200&width=200", title: "1boy 1girl black_hai..." },
  { id: 13, src: "/placeholder.svg?height=200&width=200", title: "Anime Art 13" },
  { id: 14, src: "/placeholder.svg?height=200&width=200", title: "Anime Art 14" },
  { id: 15, src: "/placeholder.svg?height=200&width=200", title: "Anime Art 15" },
  { id: 16, src: "/placeholder.svg?height=200&width=200", title: "Anime Art 16" },
  { id: 17, src: "/placeholder.svg?height=200&width=200", title: "Anime Art 17" },
  { id: 18, src: "/placeholder.svg?height=200&width=200", title: "Anime Art 18" },
]

export default function SearchPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-purple-100 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/" className="flex items-center space-x-2">
                <div className="w-10 h-10 bg-gradient-to-r from-pink-500 to-purple-600 rounded-full flex items-center justify-center">
                  <span className="text-white font-bold text-lg">P</span>
                </div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
                  Pinterest Anime
                </h1>
              </Link>
            </div>

            <div className="flex items-center space-x-4">
              <div className="flex flex-wrap gap-2">
                <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                  commentary_request
                </Badge>
                <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                  hat
                </Badge>
                <Badge variant="secondary" className="bg-green-100 text-green-800">
                  hair_between_eyes
                </Badge>
                <Badge variant="secondary" className="bg-pink-100 text-pink-800">
                  red_eyes
                </Badge>
                <Badge variant="secondary" className="bg-purple-100 text-purple-800">
                  thighhighs
                </Badge>
                <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                  dress
                </Badge>
                <Badge variant="secondary" className="bg-indigo-100 text-indigo-800">
                  persona_4
                </Badge>
                <Badge variant="secondary" className="bg-teal-100 text-teal-800">
                  jewelry
                </Badge>
              </div>

              <div className="flex items-center space-x-2">
                <Input placeholder="Nhập tags (vd: hatsune_miku long_hair)" className="w-64" defaultValue="" />
                <Button className="bg-blue-500 hover:bg-blue-600">Tìm kiếm</Button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        {/* Search Controls */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <h2 className="text-2xl font-bold text-gray-800">Kết quả tìm kiếm</h2>
            <Badge variant="outline" className="text-sm">
              {searchResults.length} kết quả
            </Badge>
          </div>

          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm">
              <Filter className="w-4 h-4 mr-2" />
              Bộ lọc
            </Button>
            <Button variant="outline" size="sm">
              <Grid className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="sm">
              <List className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Search Results Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-2">
          {searchResults.map((image) => (
            <Link key={image.id} href={`/detail/${image.id}`}>
              <div className="group relative aspect-square overflow-hidden rounded-lg bg-white shadow-sm hover:shadow-lg transition-all duration-300">
                <Image
                  src={image.src || "/placeholder.svg"}
                  alt={image.title}
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
                <div className="absolute bottom-0 left-0 right-0 p-2 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <p className="text-white text-xs font-medium truncate">{image.title}</p>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* Load More */}
        <div className="flex justify-center mt-8">
          <Button variant="outline" className="px-8 bg-transparent">
            Tải thêm
          </Button>
        </div>
      </div>

      {/* Pagination */}
      <div className="flex justify-center items-center space-x-2 py-8">
        <Button variant="outline" size="sm">
          trang trước
        </Button>
        <div className="flex space-x-1">
          <Button variant="default" size="sm">
            1
          </Button>
          <Button variant="outline" size="sm">
            2
          </Button>
          <Button variant="outline" size="sm">
            3
          </Button>
        </div>
        <Button variant="outline" size="sm">
          trang kế
        </Button>
      </div>
    </div>
  )
}
