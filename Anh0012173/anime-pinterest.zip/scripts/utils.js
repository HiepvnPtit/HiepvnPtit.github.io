// Utility functions
const tagColors = {
  nature: "tag-green",
  portrait: "tag-purple",
  landscape: "tag-blue",
  city: "tag-orange",
  abstract: "tag-red",
}

class Utils {
  static getTagColor(tag) {
    return tagColors[tag] || "tag-blue"
  }

  static formatNumber(num) {
    if (num >= 1000) {
      return (num / 1000).toFixed(1) + "k"
    }
    return num.toString()
  }

  static showLoading() {
    const overlay = document.getElementById("loadingOverlay")
    if (overlay) {
      overlay.classList.add("active")
    }
  }

  static hideLoading() {
    const overlay = document.getElementById("loadingOverlay")
    if (overlay) {
      overlay.classList.remove("active")
    }
  }

  static createImageCard(image, className = "gallery-item") {
    const card = document.createElement("div")
    card.className = className
    card.onclick = () => this.goToDetail(image.id)

    const img = document.createElement("img")
    img.src = image.src
    img.alt = image.title
    img.className = "gallery-image"
    img.loading = "lazy"

    const info = document.createElement("div")
    info.className = "gallery-info"

    const title = document.createElement("div")
    title.className = "gallery-title"
    title.textContent = image.title

    const owner = document.createElement("div")
    owner.className = "gallery-owner"
    owner.textContent = `owner: ${image.owner}`

    const tags = document.createElement("div")
    tags.className = "gallery-tags"

    // Show only first 4 tags
    image.tags.slice(0, 4).forEach((tag) => {
      const tagSpan = document.createElement("span")
      tagSpan.className = `gallery-tag ${this.getTagColor(tag)}`
      tagSpan.textContent = tag
      tags.appendChild(tagSpan)
    })

    const meta = document.createElement("div")
    meta.className = "gallery-meta"

    const size = document.createElement("span")
    size.textContent = image.size

    const stats = document.createElement("div")
    stats.className = "gallery-stats"

    if (image.likes) {
      const likes = document.createElement("div")
      likes.className = "stat-item"
      likes.innerHTML = `<i class="fas fa-heart"></i> ${this.formatNumber(image.likes)}`
      stats.appendChild(likes)
    }

    if (image.views) {
      const views = document.createElement("div")
      views.className = "stat-item"
      views.innerHTML = `<i class="fas fa-eye"></i> ${this.formatNumber(image.views)}`
      stats.appendChild(views)
    }

    meta.appendChild(size)
    meta.appendChild(stats)

    info.appendChild(title)
    info.appendChild(owner)
    info.appendChild(tags)
    info.appendChild(meta)

    card.appendChild(img)
    card.appendChild(info)

    return card
  }

  static createSidebarItem(image) {
    const item = document.createElement("div")
    item.className = "sidebar-item"
    item.onclick = () => this.goToDetail(image.id)

    const img = document.createElement("img")
    img.src = image.src
    img.alt = image.title
    img.className = "sidebar-image"
    img.loading = "lazy"

    const info = document.createElement("div")
    info.className = "sidebar-info"

    const title = document.createElement("div")
    title.className = "sidebar-item-title"
    title.textContent = image.title

    const tags = document.createElement("div")
    tags.className = "sidebar-item-tags"

    image.tags.slice(0, 3).forEach((tag) => {
      const tagSpan = document.createElement("span")
      tagSpan.className = `sidebar-tag ${this.getTagColor(tag)}`
      tagSpan.textContent = tag
      tags.appendChild(tagSpan)
    })

    info.appendChild(title)
    info.appendChild(tags)

    item.appendChild(img)
    item.appendChild(info)

    return item
  }

  static goToDetail(imageId) {
    window.location.href = `detail.html?id=${imageId}`
  }

  static goToHome() {
    window.location.href = "index.html"
  }

  static animateOnScroll() {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.style.opacity = "1"
            entry.target.style.transform = "translateY(0)"
          }
        })
      },
      {
        threshold: 0.1,
      },
    )

    document.querySelectorAll(".gallery-item, .sidebar-item").forEach((item) => {
      item.style.opacity = "0"
      item.style.transform = "translateY(20px)"
      item.style.transition = "opacity 0.6s ease, transform 0.6s ease"
      observer.observe(item)
    })
  }
}
