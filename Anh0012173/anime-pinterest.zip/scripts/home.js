// Declare Utils and animeData variables before using them
const Utils = {
  showLoading: () => {
    console.log("Loading...")
  },
  hideLoading: () => {
    console.log("Loading hidden.")
  },
  animateOnScroll: () => {
    console.log("Animating on scroll.")
  },
  createImageCard: (image) => {
    const card = document.createElement("div")
    card.className = "image-card"
    card.style.backgroundImage = `url(${image})`
    return card
  },
  createSidebarItem: (image) => {
    const item = document.createElement("div")
    item.className = "sidebar-item"
    item.style.backgroundImage = `url(${image})`
    return item
  },
}

const animeData = {
  images: ["image1.jpg", "image2.jpg", "image3.jpg"],
  sidebarImages: ["sidebarImage1.jpg", "sidebarImage2.jpg"],
}

document.addEventListener("DOMContentLoaded", () => {
  Utils.showLoading()

  // Load gallery images
  const galleryGrid = document.getElementById("galleryGrid")
  if (galleryGrid) {
    animeData.images.forEach((image, index) => {
      setTimeout(() => {
        const card = Utils.createImageCard(image)
        galleryGrid.appendChild(card)
      }, index * 100)
    })
  }

  // Load sidebar images
  const sidebarImages = document.getElementById("sidebarImages")
  if (sidebarImages) {
    animeData.sidebarImages.forEach((image, index) => {
      setTimeout(() => {
        const item = Utils.createSidebarItem(image)
        sidebarImages.appendChild(item)
      }, index * 150)
    })
  }

  // Add click handlers for header tags
  const headerTags = document.querySelectorAll(".header-tag")
  headerTags.forEach((tag) => {
    tag.addEventListener("click", function () {
      const tagText = this.textContent
      console.log(`Searching for: ${tagText}`)
      // Here you would implement search functionality
    })
  })

  // Search functionality
  const searchInput = document.querySelector(".search-input")
  const searchBtn = document.querySelector(".search-btn")

  function performSearch() {
    const query = searchInput.value.trim()
    if (query) {
      console.log(`Searching for: ${query}`)
      // Here you would implement search functionality
    }
  }

  if (searchBtn) {
    searchBtn.addEventListener("click", performSearch)
  }

  if (searchInput) {
    searchInput.addEventListener("keypress", (e) => {
      if (e.key === "Enter") {
        performSearch()
      }
    })
  }

  // Hide loading after content is loaded
  setTimeout(() => {
    Utils.hideLoading()
    Utils.animateOnScroll()
  }, 1000)

  // Add parallax effect to hero section
  window.addEventListener("scroll", () => {
    const scrolled = window.pageYOffset
    const heroImage = document.querySelector(".hero-image")
    if (heroImage) {
      heroImage.style.transform = `translateY(${scrolled * 0.5}px)`
    }
  })
})
