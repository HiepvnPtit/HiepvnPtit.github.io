document.addEventListener('DOMContentLoaded', () => {
    Utils.showLoading();
    
    // Get image ID from URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const imageId = Number.parseInt(urlParams.get('id')) || 1;
    
    // Load image details
    const image = animeData.detailImage;
    
    // Update main image
    const mainImage = document.getElementById('mainImage');
    if (mainImage) {
        mainImage.src = image.src;
        mainImage.alt = image.title;
    }
    
    // Update image info
    const imageTitle = document.getElementById('imageTitle');
    if (imageTitle) {
        imageTitle.textContent = image.title;
    }
    
    const imageOwner = document.getElementById('imageOwner');
    if (imageOwner) {
        imageOwner.textContent = image.owner;
    }
    
    const imageChange = document.getElementById('imageChange');
    if (imageChange) {
        imageChange.textContent = image.change;
    }
    
    const imageIdElement = document.getElementById('imageId');
    if (imageIdElement) {
        imageIdElement.textContent = image.imageId;
    }
    
    const imageSize = document.getElementById('imageSize');
    if (imageSize) {
        imageSize.textContent = image.size;
    }
    
    const imageStatus = document.getElementById('imageStatus');
    if (imageStatus) {
        imageStatus.textContent = image.status;
    }
    
    const imageRating = document.getElementById('imageRating');
    if (imageRating) {
        imageRating.textContent = image.rating;
    }
    
    const imageComments = document.getElementById('imageComments');
    if (imageComments) {
        imageComments.textContent = image.comments;
    }
    
    // Load tags
    const tagsContainer = document.getElementById('tagsContainer');
    if (tagsContainer) {
        image.tags.forEach((tag, index) => {
            setTimeout(() => {
                const tagSpan = document.createElement('span');
                tagSpan.className = `detail-tag ${Utils.getTagColor(tag)}`;
                tagSpan.textContent = tag;
                tagSpan.onclick = () => {
                    console.log(`Searching for tag: ${tag}`);
                    // Here you would implement tag search functionality
                };
                tagsContainer.appendChild(tagSpan);
            }, index * 50);
        });
    }
    
    // Load related images
    const relatedGrid = document.getElementById('relatedGrid');
    if (relatedGrid) {
        // Filter related images (exclude current image and get similar ones)
        const relatedImages = animeData.images
            .filter(img => img.id !== imageId)
            .slice(0, 8);
        
        relatedImages.forEach((relatedImage, index) => {
            setTimeout(() => {
                const item = document.createElement('div');
                item.className = 'related-item';
                item.onclick = () => {
                    window.location.href = `detail.html?id=${relatedImage.id}`;
                };
                
                const img = document.createElement('img');
                img.src = relatedImage.src;
                img.alt = relatedImage.title;
                img.className = 'related-image';
                img.loading = 'lazy';
                
                const info = document.createElement('div');
                info.className = 'related-info';
                
                const title = document.createElement('div');
                title.className = 'related-title';
                title.textContent = relatedImage.title;
                
                const tags = document.createElement('div');
                tags.className = 'related-tags';
                
                relatedImage.tags.slice(0, 3).forEach(tag => {
                    const tagSpan = document.createElement('span');
                    tagSpan.className = `related-tag ${Utils.getTagColor(tag)}`;
                    tagSpan.textContent = tag;
                    tags.appendChild(tagSpan);
                });
                
                info.appendChild(title);
                info.appendChild(tags);
